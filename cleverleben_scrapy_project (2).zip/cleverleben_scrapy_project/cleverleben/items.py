# cleverleben/items.py
import scrapy

class ProductItem(scrapy.Item):
    product_url = scrapy.Field()
    product_name = scrapy.Field()
    price = scrapy.Field()          # raw price seen on site (string, decimal with dot)
    regular_price = scrapy.Field()  # normalized price (string or numeric string, dot)
    currency = scrapy.Field()       # "€"
    image = scrapy.Field()          # list of image urls (field name must match spider/pipeline)
    images = scrapy.Field()         # optional - kept in case any code expects 'images'
    product_description = scrapy.Field()
    unique_id = scrapy.Field()
    ingredients = scrapy.Field()
    details = scrapy.Field()
    product_id = scrapy.Field()

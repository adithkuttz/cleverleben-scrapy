from scrapy import signals

class CleverlebenSpiderMiddleware:
    @classmethod
    def from_crawler(cls, crawler):
        s = cls()
        return s

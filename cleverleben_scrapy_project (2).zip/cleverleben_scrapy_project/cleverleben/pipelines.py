# pipelines.py
import re
import json
from w3lib.html import remove_tags

class CleanPipeline:
    """
    Normalize fields:
      - ensure all fields present
      - strip whitespace & collapse internal whitespace
      - normalize price to numeric string with dot (e.g. "2.49")
      - ensure images is a list
      - create images_csv field that is a JSON string (safe for CSV)
    """

    FIELDS = [
        "product_url","product_name","price","regular_price","currency",
        "images","product_description","unique_id","ingredients","details","product_id"
    ]

    def process_item(self, item, spider):
        # 1) Ensure keys exist
        for f in self.FIELDS:
            if f not in item:
                item[f] = None

        # 2) Clean textual fields
        for k in ("product_name","product_description","ingredients","details"):
            v = item.get(k)
            if v is None:
                continue
            # if it's a list, join
            if isinstance(v, (list,tuple)):
                v = " ".join([str(x) for x in v])
            # remove simple HTML tags if any and collapse whitespace
            v = remove_tags(str(v))
            v = re.sub(r'[\r\n\t]+', ' ', v)
            v = re.sub(r'\s{2,}', ' ', v).strip()
            item[k] = v if v else None

        # 3) Normalize price/regular_price: keep as numeric string with dot (e.g. "2.49")
        def norm_price(raw):
            if not raw:
                return None
            s = str(raw)
            # remove currency and spaces, non-digit except comma/dot
            s = s.replace('\xa0','').replace(' ', '')
            s = re.sub(r'[^\d,\.]', '', s)
            if not s:
                return None
            # if comma used as decimal separator (like "2,49"), convert to dot
            if s.count(',') and s.count('.') == 0:
                s = s.replace(',', '.')
            # if both present, assume dot is thousands? try to keep last separator as decimal
            if s.count('.') > 1:
                s = s.replace('.', '')
            if s.count(',') > 1:
                s = s.replace(',', '')
            # final safeguard: only first numeric match
            m = re.search(r'\d+(?:\.\d+)?', s)
            return m.group(0) if m else None

        item['price'] = norm_price(item.get('price')) or None
        # if regular_price absent, derive from price
        if not item.get('regular_price'):
            item['regular_price'] = item.get('price')

        # 4) Images: ensure list, absolute already in spider; convert to JSON string for CSV friendliness
        imgs = item.get('images')
        if imgs is None:
            imgs_list = []
        elif isinstance(imgs, (list, tuple)):
            imgs_list = [str(u).strip() for u in imgs if u]
        else:
            # sometimes it's a comma-joined string
            imgs_list = [s.strip() for s in str(imgs).split(',') if s.strip()]

        # deduplicate while preserving order
        seen = set()
        uniq = []
        for u in imgs_list:
            if u not in seen:
                seen.add(u)
                uniq.append(u)
        item['images'] = uniq

        # images_csv is a JSON string; safe to store in CSV cell (FEEDS will quote it)
        item['images_csv'] = json.dumps(item['images'], ensure_ascii=False)

        # 5) Final pass: convert empty strings to None
        for k in list(item.keys()):
            if isinstance(item[k], str) and item[k].strip() == "":
                item[k] = None

        return item

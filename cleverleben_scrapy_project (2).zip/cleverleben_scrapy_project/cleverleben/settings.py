# settings.py (add or update)
ITEM_PIPELINES = {
    'cleverleben.pipelines.CleanPipeline': 300,
}

# default FEEDS so running without extra CLI quoting is simpler
FEEDS = {
    'output.json': {
        'format': 'json',
        'encoding': 'utf-8',
        'indent': 2,
    },
    'output.csv': {
        'format': 'csv',
        'encoding': 'utf-8',
    },
}
